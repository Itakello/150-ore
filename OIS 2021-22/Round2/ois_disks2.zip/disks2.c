// NOTE: it is recommended to use this even if you don't understand the following code.

#include <stdio.h>
#include <assert.h>

// constraints
#define MAXN 100000

// input data
int N, T, i;
int A[MAXN], B[MAXN];

int main() {
//  uncomment the following lines if you want to read/write from files
//  freopen("input.txt", "r", stdin);
//  freopen("output.txt", "w", stdout);

    assert(2 == scanf("%d%d", &N, &T));
    for(i = 0; i < N; i++) {
        assert(2 == scanf("%d%d", &A[i], &B[i]));
    }

    // insert your code here
    
    printf("%d\n", 42); // print the result
    
    return 0;
}
